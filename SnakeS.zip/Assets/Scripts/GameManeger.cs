﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class GameManeger : MonoBehaviour
{
    [SerializeField]
    private SceneUI sceneUI;

    [SerializeField]
    private LevelManager levelManager;

    [SerializeField]
    private FoodSpawn foodSpawn;

    [SerializeField]
    private SpecialFoodSpawn1 sFoodSpawn1;

    [SerializeField]
    private SpecialFoodSpawn2 sFoodSpawn2;

    private Snake snake;

    private void Snake_OnCollision (BaseObject baseObject)
    {
        if (baseObject is Border)
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(3);
        }

        if (baseObject is Tail)
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(3);
        }

        if (baseObject is Food)
        {
            Destroy (baseObject.gameObject);

            foodSpawn.Spawn();

            sceneUI.Score.Value++;

            snake.AddTail ();
        }
        if (baseObject is SpecialFood1)
        {
            Destroy (baseObject.gameObject);

            sFoodSpawn1.Spawn();

            snake.AddTail();

            sceneUI.Score.Value = sceneUI.Score.Value + 3;
        }
        if (baseObject is SpecialFood2)
        {
            Destroy(baseObject.gameObject);

            sFoodSpawn2.Spawn();

            snake.AddTail();

            sceneUI.Score.Value = sceneUI.Score.Value + 5;
        }

        if (sceneUI.Score.Value > 5)
        {
            levelManager.NextLevel ();
        }
    }

    private void LevelManager_OnLevelWasLoaded (int index)
    {
        snake = FindObjectOfType<Snake> ();
        snake.OnCollision += Snake_OnCollision;

        foodSpawn.Spawn ();
        sFoodSpawn1.Spawn ();
    }

    void Start ()
    {
        levelManager.OnLevelWasLoaded += LevelManager_OnLevelWasLoaded;
        levelManager.NextLevel ();
    }

}

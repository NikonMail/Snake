﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuUI : MonoBehaviour
{
    [SerializeField]
    private Button start;

    [SerializeField]
    private Button exit;

    private void NewGame ()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene (0);
    }

    private void ExitGame () 
    {
        Application.Quit();
    }

    private void Start ()
    {
        start.onClick.AddListener (NewGame);
        exit.onClick.AddListener (ExitGame);
    }
}

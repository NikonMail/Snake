﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{
    public event System.Action<int> OnLevelWasLoaded;

    private void DoLevelWasLoaded ()
    {
        if (OnLevelWasLoaded != null)
        {
            OnLevelWasLoaded (levelIndex);
        }
    }

    public event System.Action<int> OnLevelWasUnloaded;

    private void DoLevelWasUnloaded ()
    {
        if (OnLevelWasUnloaded != null)
        {
            OnLevelWasUnloaded (levelIndex);
        }
    }

    private int levelIndex = 0;

    private IEnumerator LoadLevelAsync (int index)  //Загрузка сцены
    {
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync (index, LoadSceneMode.Additive);

        asyncLoad.allowSceneActivation = true;

        while (!asyncLoad.isDone)
        {
            yield return null;
        }
        yield return null;

        DoLevelWasLoaded ();
    }

    private IEnumerator UnloadSceneAsync (int index)  //Выгрузка сцены
    {
        AsyncOperation asyncLoad = SceneManager.UnloadSceneAsync (index);

        while (!asyncLoad.isDone)
        {
            yield return null;
            SceneManager.LoadScene(0);
        }

        DoLevelWasUnloaded ();
    }

    private IEnumerator _NextLevel (float delay)  //Следующий уровень
    {
        if (delay > 0f)
            yield return new WaitForSeconds (delay);

        if (levelIndex == 0)
        {
            levelIndex = 0;
        }
        else
        {
            yield return StartCoroutine (UnloadSceneAsync (levelIndex));
        }

        levelIndex = levelIndex + 1 < UnityEngine.SceneManagement.SceneManager.sceneCountInBuildSettings ? levelIndex + 1 : 0;

        yield return StartCoroutine (LoadLevelAsync (levelIndex));
    }

    private IEnumerator _Restart (float delay)  //Перезагрузка
    {
        if (delay > 0f)
            yield return new WaitForSeconds (delay);

        yield return StartCoroutine (UnloadSceneAsync (levelIndex));

        yield return StartCoroutine (LoadLevelAsync (levelIndex));
    }

    public void NextLevel (float delay = 0f)
    {
        StartCoroutine (_NextLevel (delay));
    }

    public void Restart (float delay = 0f)
    {
        StartCoroutine (_Restart (delay));
    }

    void Start ()
    {

    }
}
